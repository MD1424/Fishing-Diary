package org.mikedahl.fishingdiary;


import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.Test;

@SpringBootTest
class FishingDiaryApplicationTests {

    @Test
    void contextLoads() {
    }

}
