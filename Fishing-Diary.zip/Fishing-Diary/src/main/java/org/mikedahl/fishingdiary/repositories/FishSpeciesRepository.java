package org.mikedahl.fishingdiary.repositories;

import org.mikedahl.fishingdiary.models.FishSpecies;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FishSpeciesRepository extends JpaRepository<FishSpecies, String> {
}
