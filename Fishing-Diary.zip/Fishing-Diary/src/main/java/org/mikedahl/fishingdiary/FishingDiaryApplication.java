package org.mikedahl.fishingdiary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FishingDiaryApplication {

    public static void main(String[] args) {
        SpringApplication.run(FishingDiaryApplication.class, args);
    }

}
